<?php

$menu['Announcements']['admin'] = array(
    'title' => _('Announcements'),
    'default' => 'Announcements/New.php',
    'Announcements/New.php' => _('New Announcement'),
);

$menu['Announcements']['teacher'] = array(
    'title' => _('Announcements'),
    'default' => 'Announcements/New.php',
    'Announcements/New.php' => _('New Announcement'),
);